.. _clients :

WPS Clients
***********
In this chapter, several (Py)WPS clients will be described. Some of them
are part of the PyWPS distribution, others can be found on the Internet.

.. toctree::
   :maxdepth: 2

   javascript
   qgis
