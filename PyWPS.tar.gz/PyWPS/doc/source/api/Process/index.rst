Module Process
==============

.. toctree::
    :maxdepth: 2

    Lang
    InAndOutputs

.. automodule:: pywps.Process

Class  Status
.............
.. autoclass:: Status
    :members:

Class WPSProcess
................
.. autoclass:: WPSProcess
    :members:
