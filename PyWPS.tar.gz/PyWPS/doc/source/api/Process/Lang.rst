Module Lang
-----------

.. automodule:: pywps.Process.Lang

Class Lang
..........
.. autoclass:: Lang
    :members:
