Module GetCapabilities
----------------------
.. automodule:: pywps.Parser.GetCapabilities

Class Post
..........
.. autoclass:: Post
    :members:

Class Get
.........
.. autoclass:: Get
    :members:
