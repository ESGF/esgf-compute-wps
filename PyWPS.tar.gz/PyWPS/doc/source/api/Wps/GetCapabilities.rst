WPS GetCapabilities request handler
-----------------------------------
.. automodule:: pywps.Wps.GetCapabilities

Class GetCapabilities
.....................
.. autoclass:: GetCapabilities
    :members:
