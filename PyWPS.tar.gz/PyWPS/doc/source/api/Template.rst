.. automodule:: pywps.Template
    :members:
